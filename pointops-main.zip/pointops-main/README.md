# pointops

Original code repo [point-transformer](https://github.com/POSTECH-CVLab/point-transformer).

I build this repo for directly installing pointops with 

```bash
pip install "git+https://github.com/Silverster98/pointops"
```

Modification:

1. Comment `#include <THC/THC.h>` for using `pytorch` with latest pytorch version.
